Warung Starter Kit — Premium

Deskripsi:
Template warung/UMKM: menu page, QR menu, tombol WA order, printable A4 menu.

File di paket:
- index.html
- styles.css
- screenshot.png
- README.md

Demo (ganti dengan GitHub Pages atau demo link kamu):
https://example.com/demo/warung-starter

Cara gunakan / edit cepat:
1. Extract file.
2. Buka index.html dan edit konten (judul, harga, gambar).
3. Ganti nomor WhatsApp di link (format internasional, tanpa +). Contoh: 6281234567890
4. Upload folder ke GitHub Pages atau host statis (Netlify, Vercel, GitHub Pages).
5. Untuk versi ZIP di Gumroad: sertakan README, 3 screenshot (desktop/mobile), dan dokumentasi singkat.

Lisensi:
Dijual dengan lisensi standar - personal & commercial use oleh pembeli. Sesuaikan kebijakan lisensi saat upload.

Butuh saya bantu untuk mengubah demo link / menambahkan screenshot yang lebih bagus?"
